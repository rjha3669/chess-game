import React from "react";
import ReactDOM from "react-dom";
import Config from "./config"
import "./style.css";

function App() {
  return (
    <div className="App">
      <ChessgameComponent></ChessgameComponent>
    </div>
  );
}

class Captures extends React.Component {
  render() {
    let capturedPieces = "";

    this.props.captures.forEach(piece => {
      capturedPieces += piece.symbol;
    });

    return (
      <div>
        <h4>Captured by {this.props.player}</h4>
        <p>{capturedPieces}</p>
      </div> 
    );
  }
}

class ChessgameComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = Config;
  }

  handleClick(i) {
    let board = this.state.board;
    let highlights = this.state.highlights;
    let capturedByBlack = this.state.capturedByBlack;
    let capturedByWhite = this.state.capturedByWhite;
    let selected = this.state.selected;
    let isWhiteTurn = this.state.isWhiteTurn;
    let currentPlayer = isWhiteTurn ? "white" : "black";
    
    if (!board[i] && !selected) {
      console.log("Ignore empty squares");
      return;
    }

    if (!highlights[i] && board[i].player === currentPlayer) {
      console.log("Selected piece");
      let newState = this.state;
      newState.selected = i;
      newState.highlights = this.calculateHighlights(board[i], newState.selected);
      this.setState(newState);
      console.log("Updated");
      return;
    }
    
    if (selected && highlights[i]) {
      console.log("Move to " + i);
      let newState = this.state;

      if (board[i]) {
        if (currentPlayer === "white") {
          capturedByWhite.push(board[i]);
        } else {
          capturedByBlack.push(board[i]);
        }
      }

      newState.board[i] = board[selected];
      newState.board[selected] = null;

      if (newState.board[i].moved === false) {
        newState.board[i].moved = true;
      }

      newState.capturedByBlack = capturedByBlack;
      newState.capturedByWhite = capturedByWhite;
      newState.highlights = Array(64).fill(null);
      newState.selected = null;
      newState.isWhiteTurn = !newState.isWhiteTurn;
      this.setState(newState);
    }
  }

  calculateHighlights(selectedPiece, i) {
    const highlightsArray = Array(64).fill(null);
    
    switch (selectedPiece.piece) {
      case "pawn":
        return this.calculatePawnHighlights(highlightsArray, selectedPiece, i);
      case "rook":
        return this.calculateRookHighlights(highlightsArray, selectedPiece, i);
      case "bishop":
        return this.calculateRookHighlights(highlightsArray, selectedPiece, i);
      default:
        console.error("Unknown piece selected");
        break;
    }

    return highlightsArray;
  }

  calculatePawnHighlights(highlightsArray, selectedPiece, i) {
    if (selectedPiece.player === "white") {
      try {
        if (!selectedPiece.moved) {
          highlightsArray[i - 8] = (this.state.board[i - 8]) ? null : true;
          highlightsArray[i - 16] = (this.state.board[i - 16] || this.state.board[i - 8]) ? null : true;
        } else {
          highlightsArray[i - 8] = (this.state.board[i - 8]) ? null : true;
        }

        try {
          highlightsArray[i - 7] = (this.state.board[i - 7].player === "black" &&  i % 8 !== 7) ? true : null;
        } catch (e) {}
        
        try {
          highlightsArray[i - 9] = (this.state.board[i - 9].player === "black" && i % 8 !== 0) ? true : null;
        } catch (e) {}
        
      } finally {
        
      }
    } else { 
      try {
        if (!selectedPiece.moved) {
          highlightsArray[i + 8] = (this.state.board[i + 8]) ? null : true;
          highlightsArray[i + 16] = (this.state.board[i + 16]  || this.state.board[i + 8]) ? null : true;
        } else {
          highlightsArray[i + 8] = (this.state.board[i + 8]) ? null : true;;
        }
      } finally {
        
      }

      try {
        highlightsArray[i + 7] = (this.state.board[i + 7].player === "white" &&  i % 8 !== 0) ? true : null;
      } catch (e) {}
      
      try {
        highlightsArray[i + 9] = (this.state.board[i + 9].player === "white" && i % 8 !== 7) ? true : null;
      } catch (e) {}
    }

    return highlightsArray;
  }

  isEnemy(i, player) {
    
  }

  calculateRookHighlights(highlightsArray, selectedPiece, i) {
    
  }

  render() {
    return (
      <div>
        <BoardComponent pieces={this.state.board} highlights={this.state.highlights} onClick={i => this.handleClick(i)}></BoardComponent>
        <Captures captures={this.state.capturedByWhite} player="white"></Captures>
        <Captures captures={this.state.capturedByBlack} player="black"></Captures>
      </div>
    );
  }
}

class BoardComponent extends React.Component {
  renderBoard() {
    const rows = [];

    let dark = false;

    for (let i = 0; i < 8; i++) {
      let row = [];

      for (let j = 0; j < 8; j++) {
        row.push(this.renderSquare(8 * i + j, dark));
        dark = !dark;
      }

      dark = !dark;
      rows.push(<div className="board-row">{row}</div>);
    }

    return <div>{rows}</div>;
  }

  renderSquare(i, dark) {
    return (
      <SquareComponent
        piece={this.props.pieces[i]}
        dark={dark}
        active={this.props.highlights[i]}
        onClick={() => this.props.onClick(i)}
      >
      </SquareComponent>
    );
  }

  render() {
    return <div>{this.renderBoard()}</div>;
  }
}

function SquareComponent(props) {
  let cssClasses = "square";

  if (props.dark) {
    cssClasses += " dark";
  }

  if (props.active) {
    cssClasses += " valid";
  }

  return (
    <button className={cssClasses} onClick={props.onClick}>
      {(props.piece) ? props.piece.symbol : ""}
    </button>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
